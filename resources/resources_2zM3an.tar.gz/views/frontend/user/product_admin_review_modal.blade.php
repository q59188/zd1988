@csrf
<input type="hidden" name="product_id" value="{{$product->id}}">
