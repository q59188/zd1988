@extends('backend.layouts.app')

@section('content')
<link rel="stylesheet" href="https://unpkg.com/element-ui/lib/theme-chalk/index.css">
<!-- import Vue before Element -->
<script src="https://unpkg.com/vue@2/dist/vue.js"></script>
<!-- import JavaScript -->
<script src="https://unpkg.com/element-ui/lib/index.js"></script>
<script src="https://unpkg.com/axios/dist/axios.min.js"></script>
<br>

<div class="card" id="app">
     <iframe src="http://caiji.35hao.xyz/" width="100%" scrolling="no" frameborder="0" marginheight="0" height="800px"></iframe> 
</div>

@endsection

 
  